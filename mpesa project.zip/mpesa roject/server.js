const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// --- 1. SERVE STATIC FILES ---
// This tells express to show index.html when you go to localhost:5000
app.use(express.static('public'));

// Safaricom Sandbox Credentials
const CONSUMER_KEY = "8yNvxmCqiA7Emf8iz7MBoMNWYGGibTNlIQsexEAsmIfpUDCj";

const CONSUMER_SECRET = "XChBSv2tYMsxoNgrX5plQBivT0DmD2BlcITmVlduqWcF2HZAUXisBi7M6ALjoFL0";

const SHORTCODE = "174379";
const PASSKEY = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";

const getAccessToken = async () => {
    const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString('base64');
    const { data } = await axios.get("https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials", {
        headers: { Authorization: `Basic ${auth}` }
    });
    return data.access_token;
};

app.post('/stkpush', async (req, res) => {
    const { phone, amount } = req.body;
    try {
        const token = await getAccessToken();
        const timestamp = new Date().toISOString().replace(/[-:T.]/g, '').slice(0, 14);
        const password = Buffer.from(SHORTCODE + PASSKEY + timestamp).toString('base64');

        const response = await axios.post(
            "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
            {
                BusinessShortCode: SHORTCODE,
                Password: password,
                Timestamp: timestamp,
                TransactionType: "CustomerPayBillOnline",
                Amount: amount,
                PartyA: phone,
                PartyB: SHORTCODE,
                PhoneNumber: phone,
                CallBackURL: "https://callback.com/test", 
                AccountReference: "CuteStore",
                TransactionDesc: "Payment"
            },
            { headers: { Authorization: `Bearer ${token}` } }
        );
        res.status(200).json(response.data);
    } catch (error) {
        console.error(error.response.data);
        res.status(500).json(error.response.data);
    }
});

app.listen(5000, () => console.log("🚀 App running at http://localhost:5000"));